
/**
 * Write a description of class LibraryCard here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class LibraryCard
{
    private int booksLimit;
    private int booksBorrowed;
    private String cardReference;

    public LibraryCard(int limit, int setReference)
    {
        booksLimit = limit;
        cardReference = "cardID " + setReference;
        booksBorrowed = 0;
    }
    
    public void swipe()
    {
        booksBorrowed = booksBorrowed + 1;
    }
    
    public boolean expired()
    {
        return booksBorrowed >= booksLimit;
    }
    
    public String getCardRef()
    {
        return cardReference;
    }
    
    public void describe()
    {
        System.out.println("Library card " + getCardRef() + " with " + (booksLimit - booksBorrowed) + " books left");
    }
}
