
/**
 * Write a description of class LibraryClass here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class LibraryClass
{
    private TextBook[] bookShelf;
    private int nextBook;
    private int borrowersNumber;

    /**
     * Constructor for objects of class LibraryClass
     */
    public LibraryClass(int maxNumTextBook)
    {
        borrowersNumber = 0;
        
        bookShelf = new TextBook[maxNumTextBook]; 
        
        for (int x = 0; x < maxNumTextBook; x++)
        {
            bookShelf[x] = new TextBook("text book "+ (x+1), 4);
        }
    }
 
    public LibraryCard issueCard()
    {
        borrowersNumber = borrowersNumber + 1;
        return new LibraryCard(5, borrowersNumber - 1);
    }
    
    public TextBook borrowBook(LibraryCard card)
    {
        if((!card.expired()) && (nextBook < bookShelf.length))
        {
            TextBook book = bookShelf[nextBook];
            bookShelf[nextBook] = null;
            nextBook = nextBook + 1;
            card.swipe();
            return book;
        }
        else
        {
            return null;
        }
    }
    
    public void returnBook(TextBook book)
    {
        bookShelf[nextBook - 1] = book;
        nextBook = nextBook - 1;
    }
    
    public void describe()
    {
        System.out.println("The library has " + (bookShelf.length - nextBook) + " books left on the shelf and has issued "  + borrowersNumber + " library cards");
    }
}
