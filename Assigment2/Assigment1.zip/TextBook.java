
/**
 * Write a description of class TextBook here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TextBook
{
    private String textBookTitle;
    private int chapterNumber;
    private int chaptersRead;
    
    public TextBook(String title, int length)
    {
        textBookTitle = title;
        chapterNumber = length;
        chaptersRead = 0;
    }

    public String getTitle()
    {
        return textBookTitle;
    }
    
    public void readNextChapter()
    {
        if (!isFinished())
        {
            chaptersRead = chaptersRead + 1;
        }
        
        else
        {
            System.out.println("Book has been read!");
        }
    }
    
    public boolean isFinished()
    {
        return chaptersRead == chapterNumber;
    }
    
    public void closeBook()
    {
        chaptersRead = 0;
    }
    
    public void describe()
    {
        System.out.println(textBookTitle + " with " + (chapterNumber-chaptersRead) + " chapters left to read");
    }
}
